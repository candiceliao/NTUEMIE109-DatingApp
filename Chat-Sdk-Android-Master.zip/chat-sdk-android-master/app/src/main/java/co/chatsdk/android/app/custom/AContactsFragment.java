package co.chatsdk.android.app.custom;

import android.os.Bundle;

import co.chatsdk.ui.contacts.ContactsFragment;

public class AContactsFragment extends ContactsFragment {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}
