package co.chatsdk.android.app.custom;

import android.os.Bundle;

import co.chatsdk.ui.login.LoginActivity;

public class ALoginActivity extends LoginActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}
