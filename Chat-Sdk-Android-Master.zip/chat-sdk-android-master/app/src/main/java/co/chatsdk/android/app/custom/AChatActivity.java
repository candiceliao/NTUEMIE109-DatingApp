package co.chatsdk.android.app.custom;

import android.os.Bundle;

import co.chatsdk.ui.chat.ChatActivity;

public class AChatActivity extends ChatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}
