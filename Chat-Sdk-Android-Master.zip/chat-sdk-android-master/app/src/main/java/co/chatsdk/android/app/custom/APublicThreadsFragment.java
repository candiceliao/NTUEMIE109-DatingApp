package co.chatsdk.android.app.custom;

import android.os.Bundle;

import co.chatsdk.ui.threads.PublicThreadsFragment;

public class APublicThreadsFragment extends PublicThreadsFragment {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}
