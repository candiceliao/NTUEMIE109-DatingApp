package co.chatsdk.android.app.custom;

import android.os.Bundle;

import co.chatsdk.ui.profile.ProfileActivity;

public class AProfileActivity extends ProfileActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}
