package co.chatsdk.android.app.custom;

import android.os.Bundle;

import co.chatsdk.ui.threads.PrivateThreadsFragment;

public class APrivateThreadsFragment extends PrivateThreadsFragment {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}
