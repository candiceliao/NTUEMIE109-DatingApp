package co.chatsdk.core.types;

/**
 * Created by benjaminsmiley-andrews on 06/07/2017.
 */

public class KeyValue {

    public String key;
    public String value;

    public KeyValue (String key, String value) {
        this.key = key;
        this.value = value;
    }
}
