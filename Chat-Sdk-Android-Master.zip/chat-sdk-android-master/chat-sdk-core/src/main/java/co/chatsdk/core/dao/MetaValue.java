package co.chatsdk.core.dao;

/**
 * Created by ben on 5/17/18.
 */

public interface MetaValue {

    String getKey();
    String getValue();

    void setKey(String key);
    void setValue (String value);

}
