package co.chatsdk.core.base;

import co.chatsdk.core.handlers.MessageHandler;
import co.chatsdk.core.interfaces.MessageDisplayHandler;

public abstract class AbstractMessageHandler implements MessageHandler {

}
