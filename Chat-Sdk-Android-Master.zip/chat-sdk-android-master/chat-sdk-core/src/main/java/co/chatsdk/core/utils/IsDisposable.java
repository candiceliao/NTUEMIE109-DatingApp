package co.chatsdk.core.utils;

/**
 * Created by ben on 8/25/17.
 */

public interface IsDisposable {

    void dispose ();

}
