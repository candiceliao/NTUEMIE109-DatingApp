package co.chatsdk.core.types;

/**
 * Created by benjaminsmiley-andrews on 04/05/2017.
 */

public class AuthKeys {
    public static final String CurrentUserID = "auth-current-user-id";
}
