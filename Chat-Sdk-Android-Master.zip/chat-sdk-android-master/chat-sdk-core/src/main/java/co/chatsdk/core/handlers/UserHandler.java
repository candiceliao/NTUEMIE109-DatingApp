package co.chatsdk.core.handlers;

/**
 * Created by SimonSmiley-Andrews on 01/05/2017.
 */

public interface UserHandler {
}
