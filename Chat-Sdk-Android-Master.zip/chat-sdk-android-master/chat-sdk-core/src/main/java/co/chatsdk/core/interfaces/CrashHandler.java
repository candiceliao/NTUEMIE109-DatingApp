package co.chatsdk.core.interfaces;

/**
 * Created by ben on 4/26/18.
 */

public interface CrashHandler {
    void log (Exception e);
}
